// Construtor

class ProfessorModel {

    constructor(id, nome, curso, titulacao, ai) {
        this.id = id
        this.nome = nome
        this.curso = curso
        this.titulacao = titulacao
        this.ai = ai
    }

}

module.exports = ProfessorModel