import './App.css';

import MP from './componentes/02Crud/MainPage'

function App() {
  return (
   <MP/>
  )
}

export default App;
