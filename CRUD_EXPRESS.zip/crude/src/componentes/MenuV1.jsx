import {AppBar, Container, Toolbar, Typography, Box, Button, Menu, MenuItem} from "@mui/material";
import AdbIcon from "@mui/icons-material/Adb";
import { Link } from "react-router-dom";
import { useState } from "react";

const Menu_v1 = () => {

    const [anchorElProf, setAnchorElProf] = useState(null)

    const handleOpenAnchorElProf = (event) => {
        setAnchorElProf(event.currentTarget)
    }
    const handleCloseAnchorElProf = () => {
        setAnchorElProf(null)
    }

    function dropProfMenu(){
        return(
            <Box>
                <Button
                    sx={{ color: "white", my: 2 }}
                    onClick={handleOpenAnchorElProf}
                >
                    Professores
                </Button>
                <Menu
                    anchorEl={anchorElProf}
                    open={Boolean(anchorElProf)}
                    onClose={handleCloseAnchorElProf}
                >
                    <MenuItem onClick={handleCloseAnchorElProf} component={Link} to={"cadProfessor"}>Cadastrar</MenuItem>
                    <MenuItem
                    onClick={handleCloseAnchorElProf}
                    component={Link}
                    to={"listProfessor"}
                    >Listar</MenuItem>
                </Menu>
            </Box>
        );
    }

    return(
        // barra fica estática
        <AppBar position="static"> 
            <Container>
                <Toolbar>
                    <AdbIcon sx={{display:{xs:"none", md:"flex"}, mr:1}}/>
                    <Typography 
                        variant="h5" 
                        component="a" 
                        href="/" 
                        sx={{textDecoration:"none", color:"white", fontFamily:"monospace", letterSpacing:".3rem", fontWeight:800}}
                    >
                        CRUDE_V1
                    </Typography>
                    <Box sx={{ml:3, width:"100%", display:"flex", justifyContent:"flex-end"}} >
                        {dropProfMenu()}
                        <Button
                            sx={{color:"white", my:2}}
                        >
                            Alunos
                        </Button>
                        <Button
                            sx={{color:"white", my:2}}
                        >
                            Sobre
                        </Button>
                    </Box>
                </Toolbar>
            </Container>
        </AppBar>
    );
}

export default Menu_v1