const EditarProf = () => {
    return(
        <>
            Editar Professor
        </>
    )
}

export default EditarProf