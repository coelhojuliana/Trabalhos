import { Typography, Box, TextField, FormControl, FormControl, InputLabel, Select, MenuItem } from "@mui/material"

const Cadastrar = () => {
    return(
        <>
            <Typography variant="h5" fontWeight="bold">
                Cadastrar
            </Typography>
            <Box>
                <TextField 
                    margin="normal"
                    required
                    fullWidth
                    id="nome"
                    name="nome"
                    label = "Nome completo"
                    autoFocus
                />
                <TextField 
                    margin="normal"
                    required
                    fullWidth
                    id="curso"
                    name="curso"
                    label = "Curso"
                />
                <FormControl fullWidth sx={{mt:2}}>
                    <InputLabel id="select-tit-label">Titulação</InputLabel>
                    <Select labelId="select-tit-label" label="Titulação">
                        <MenuItem value="GRAD"></MenuItem>
                        <MenuItem value="MEST"></MenuItem>
                        <MenuItem value="DOUT"></MenuItem>
                    </Select>
                </FormControl>
            </Box>
        </>
    )
}

export default Cadastrar