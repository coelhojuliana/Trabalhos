const ListarProf = () => {
    return(
        <>
            Listar Professor
        </>
    )
}

export default ListarProf