import { TableCell, Paper, Table, TableBody, TableContainer, TableHead, TableRow, Typography, Box } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { styled } from "@mui/material/styles";
import { tableCellClasses } from "@mui/material/TableCell";
import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";


const Listar = () => {

const [professores, setProfessores] = useState([])
const navigate = useNavigate()
const [mudou, setMudou] = useState(false)

useEffect(
    ()=>{
        axios.get("http://localhost:3001/professores/listar")
        .then(
            (response)=>{
                
                setProfessores(response.data)
            }
        )
        .catch(error=>console.log(error))
    }
    ,
    []
)

    function deleteProfessorbyId(id){
        if(window.confirm("Tem certeza disso?")){
            axios.delete(`http://localhost:3001/professores/apagar/${id}`)
            .then(
                (response)=>{
                    apagarTeste(id)
                    setMudou(!mudou)
                }
            )
            .catch(error=>console.log(error))
        }
    }

    function apagarTeste(id) {
        for (let i = 0; i < professores.length; i++) {
            if (professores[i]._id == id) {
                professores.splice(i, 1)
                return true
            }
        }
        return false
    }

    return (
        <>
            <Typography variant="h5" fontWeight="bold">
                Listar Professor
            </Typography>
            <TableContainer component={Paper} sx={{my:3}}>
                <Table sx={{minWidth:650}} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>ID</StyledTableCell>
                            <StyledTableCell>NOME</StyledTableCell>
                            <StyledTableCell>CURSO</StyledTableCell>
                            <StyledTableCell>TITULAÇÃO</StyledTableCell>
                            <StyledTableCell>AÇÕES</StyledTableCell>

                        </TableRow>

                    </TableHead>
                    <TableBody>
                        
                    {
                        professores.map(
                            (professor)=>{
                                return (
                                    <StyledTableRow key={professor._id}>
                                        <StyledTableCell>{professor._id}</StyledTableCell>
                                        <StyledTableCell>{professor.nome}</StyledTableCell>
                                        <StyledTableCell>{professor.curso}</StyledTableCell>
                                        <StyledTableCell>{professor.titulacao}</StyledTableCell>
                                        <StyledTableCell>
                                            <Box>
                                                <IconButton aria-label="edit" color="primary" component={Link} to={`/editarprofessor/${professor._id}`}>
                                                    <EditIcon/>
                                                </IconButton>
                                                <IconButton aria-label="delete" color="error" onClick={()=>deleteProfessorbyId(professor._id)}>
                                                    <DeleteIcon/>
                                                </IconButton>
                                            </Box>
                                        </StyledTableCell>

                                    </StyledTableRow>
                                )
                            }
                        )

                    }

                    </TableBody>
                </Table>
                
            </TableContainer>
        </>
    )
}

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));

export default Listar;