import { TableCell, Paper, Table, TableBody, TableContainer, TableHead, TableRow, Typography, Box, TableFooter } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { styled } from "@mui/material/styles";
import { tableCellClasses } from "@mui/material/TableCell";
import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";


const ListarAluno = () => {


const [alunos, setAlunos] = useState([])
const navigate = useNavigate()
const [mudou, setMudou] = useState(false)

useEffect(
    ()=>{
        axios.get("http://localhost:3001/alunos/listar")
        .then(
            (response)=>{

                setAlunos(response.data)
            }
        )
        .catch(error=>console.log(error))
    }
    ,
    []
)

    function deleteAlunobyId(id){
        if(window.confirm("Tem certeza disso?")){
            axios.delete(`http://localhost:3001/alunos/apagar/${id}`)
            .then(
                (response)=>{
                    apagarTeste(id)

                    setMudou(!mudou)
                }
            )
            .catch(error=>console.log(error))
        }
    }

    function apagarTeste(id) {
        for (let i = 0; i < alunos.length; i++) {
            if (alunos[i]._id == id) {
                alunos.splice(i, 1)
                return true
            }
        }
        return false
    }

    // QUEST1: Fizemos uma função que pega e soma todos os Iras e depois divide pelo numeto de alunos cadastrados
    function mediaIra(){
        var notas = 0;
        for(var i=0; i<alunos.length;i++){
            notas += alunos[i].ira
        }

        return notas/alunos.length //retorna a soma dos iras divida pelo numero de alunos
    }

    //QUEST 1: BONUS 
    // Fizemos 2 funções, uma para alterar a cor da borda da tablerow e outra para alterar a cor do texto
    // As funções pegam o valor do ira, verificam se está abaixo ou acima da média e retornam o estilo que será aplicado na tag
    function alunoRepBorder(ira){
        if(ira < 7){
            return "2px solid red"
        }
        return "none"
    }

    function alunoRepNome(ira){
        if(ira < 7){
            return "red"
        }
        return "black"
    }

    return (
        <>
            <Typography variant="h5" fontWeight="bold">
                Listar Aluno
            </Typography>
            <TableContainer component={Paper} sx={{my:3}}>
                <Table sx={{minWidth:650}} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>ID</StyledTableCell>
                            <StyledTableCell>NOME</StyledTableCell>
                            <StyledTableCell>CURSO</StyledTableCell>
                            <StyledTableCell>IRA</StyledTableCell>
                            <StyledTableCell>AÇÕES</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        
                    {
                        alunos.map(
                            (aluno)=>{
                                return (
                                    <StyledTableRow key={aluno._id}
                                        // QUEST 1:BONUS - Aplicando o estilo da borda pelo retorno da função
                                        style={{border: alunoRepBorder(aluno.ira)}} 
                                    >
                                        <StyledTableCell>{aluno._id}</StyledTableCell>
                                        <StyledTableCell
                                            // QUEST 1:BONUS - Aplicando o estilo do texto pelo retorno da função
                                            sx={{color: alunoRepNome(aluno.ira)}}
                                        >{aluno.nome}</StyledTableCell>
                                        <StyledTableCell>{aluno.curso}</StyledTableCell>
                                        <StyledTableCell>{aluno.ira}</StyledTableCell>
                                        <StyledTableCell>
                                            <Box>
                                                <IconButton aria-label="edit" color="primary" component={Link} to={`/editaraluno/${aluno._id}`}>
                                                    <EditIcon/>
                                                </IconButton>
                                                <IconButton aria-label="delete" color="error" onClick={()=>deleteAlunobyId(aluno._id)}>
                                                    <DeleteIcon/>
                                                </IconButton>
                                            </Box>
                                        </StyledTableCell>
                                    </StyledTableRow>
                                )
                            }
                        )
                    }
                    </TableBody>
                    {/* QUEST 1: */}
                    {/* Adicionamos um footer para a tabela que contém somente uma linha com a media do ira */}
                    {/* optamos por utilizar a construção padrão da tabela ao invés de adicionar uma linha estática no body dela */}
                    <TableFooter>
                        <TableRow>
                            <StyledTableCell>{"IRA GERAL: " + mediaIra()}</StyledTableCell>
                        </TableRow>
                    </TableFooter>
                </Table>
                
            </TableContainer>
        </>

    )
}

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));

export default ListarAluno;