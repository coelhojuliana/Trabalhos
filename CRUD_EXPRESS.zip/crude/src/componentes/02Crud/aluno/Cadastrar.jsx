import { Box, InputLabel, Select, FormControl, TextField, Typography, MenuItem, Button, FormGroup, FormControlLabel, Checkbox, FormLabel} from "@mui/material"
import { useState } from "react"
import axios from "axios"
import { useNavigate } from "react-router-dom"

const CadastrarAluno = () => {

    const [nome, setNome] = useState("")
    //QUEST 03: variavel que vai receber o valor do input de seleção.
    const [curso, setCurso] = useState("") 
    const [ira, setIra] = useState(0)
    
    

    const navigate = useNavigate()
    
    function handleSubmit(event) {
        event.preventDefault()

        const novoAluno = {nome, curso, ira}
        axios.post("http://localhost:3001/alunos/criar", novoAluno)
        .then(
            (response)=>{
                alert(`Aluno ID ${response.data._id} adicionado!`)
                navigate("/listarAluno")
            }
        )
        .catch(error=>console.log(error))
    }

    return (
        <>
            <Typography variant="h5" fontWeight="bold">
                Cadastrar Aluno
            </Typography>
        
            <Box
                component="form"
                onSubmit={handleSubmit}
            >
                <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="nome"
                    name="nome"
                    label="Nome Completo"
                    autoFocus
                   
                    onChange={(event) => setNome(event.target.value)}
                />

                {/* QUEST 03: O input de textfield foi substituido por unm input de seleção */}
                <FormControl fullWidth sx={{ mt: 2 }}>
                    <InputLabel id="select-cu-label">Curso</InputLabel>
                    <Select
                        labelId="select-cu-label"
                        label="Curso"
                        value={curso}
                        onChange={(event) => setCurso(event.target.value)}
                    >
                        {/* QUEST 03: itens para a seleção do curso. o select irá pegar o value do item selecionado */}
                        <MenuItem value="DD">DD</MenuItem>
                        <MenuItem value="CC">CC</MenuItem>
                        <MenuItem value="SI">SI</MenuItem>
                        <MenuItem value="ES">ES</MenuItem>
                        <MenuItem value="EC">EC</MenuItem>
                        <MenuItem value="RC">RC</MenuItem>
                    </Select>
                </FormControl>

                <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="ira"
                    name="ira"
                    label="Ira"
                    onChange={(event) => setIra(event.target.value)}
                />

                
                <Box sx={{display:"flex", justifyContent:"center"}}>
                    <Button
                        type="submit"
                        variant="contained"
                        sx={{ my: 3 }}
                    >
                        Cadastrar
                    </Button>

                </Box>
            </Box>
        </>
    )
}

export default CadastrarAluno;