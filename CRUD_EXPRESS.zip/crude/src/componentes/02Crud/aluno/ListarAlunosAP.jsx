import { TableCell, Paper, Table, TableBody, TableContainer, TableHead, TableRow, Typography, Box, TableFooter } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { styled } from "@mui/material/styles";
import { tableCellClasses } from "@mui/material/TableCell";
import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";


const ListarAlunosAP = () => {

const [alunos, setAlunos] = useState([])
const navigate = useNavigate()
const [mudou, setMudou] = useState(false)

useEffect(
    ()=>{
        axios.get("http://localhost:3001/alunos/listar")
        .then(
            (response)=>{
                setAlunos(response.data)
            }
        )
        .catch(error=>console.log(error))
    }
    ,
    []
)

    function deleteAlunobyId(id){
        if(window.confirm("Tem certeza disso?")){
            axios.delete(`http://localhost:3001/alunos/apagar/${id}`)
            .then(
                (response)=>{
                 
                    apagarTeste(id)
            
                    setMudou(!mudou)
                }
            )
            .catch(error=>console.log(error))
        }
    }

    function apagarTeste(id) {
        for (let i = 0; i < alunos.length; i++) {
            if (alunos[i]._id == id) {
                alunos.splice(i, 1)
                return true
            }
        }
        return false
    }

    function mediaIra(){
        var notas = 0;
        for(var i=0; i<alunos.length;i++){
            notas += alunos[i].ira
        }

        return notas/alunos.length
    }
    // QUEST 02: Criamos um vetor para armazenar todos os usuarios que foram aprovados
    var alunosAp = []

    //QUEST 02: A função recebe um vetor de objetos (alunos), verifica qual deles estao com o ira acima de 7 
    //e insere eles no vetor de alunos aprovados (alunosAp)
    function aprovadosIra(vt){
        for(var i = 0; i<vt.length; i++){
            if(vt[i].ira >= 7){
                alunosAp.push(vt[i]);
            }
        }
        return alunosAp
        //QUEST 02: retorna o vetor com somente os alunos aprovados
    }

    aprovadosIra(alunos)

    return (
        <>
            <Typography variant="h5" fontWeight="bold">
                Listar Alunos aprovados
            </Typography>
            <TableContainer component={Paper} sx={{my:3}}>
                <Table sx={{minWidth:650}} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>ID</StyledTableCell>
                            <StyledTableCell>NOME</StyledTableCell>
                            <StyledTableCell>CURSO</StyledTableCell>
                            <StyledTableCell>IRA</StyledTableCell>
                            <StyledTableCell>AÇÕES</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                    {

                        //QUEST 02: Utiliza o vetor que contem somente os aprovados para listar
                        alunosAp.map(
                            (aluno)=>{
                                return (
                                    <StyledTableRow key={aluno._id}>
                                        <StyledTableCell>{aluno._id}</StyledTableCell>
                                        <StyledTableCell>{aluno.nome}</StyledTableCell>
                                        <StyledTableCell>{aluno.curso}</StyledTableCell>
                                        <StyledTableCell>{aluno.ira}</StyledTableCell>
                                        <StyledTableCell>
                                            <Box>
                                                <IconButton aria-label="edit" color="primary" component={Link} to={`/editaraluno/${aluno._id}`}>
                                                    <EditIcon/>
                                                </IconButton>
                                                <IconButton aria-label="delete" color="error" onClick={()=>deleteAlunobyId(aluno._id)}>
                                                    <DeleteIcon/>
                                                </IconButton>
                                            </Box>
                                        </StyledTableCell>
                                    </StyledTableRow>
                                )
                            }
                        )

                    }

                    </TableBody>
                    <TableFooter>
                        <TableRow>
                            <StyledTableCell>{"IRA GERAL: " + mediaIra()}</StyledTableCell>
                        </TableRow>
                    </TableFooter>
                </Table>
                
            </TableContainer>
        </>

    )
}

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));

export default ListarAlunosAP;