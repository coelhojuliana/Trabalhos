import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Container } from "@mui/material"
import MenuV1 from './MenuV1'
import CadastrarProf from './professor/Cadastrar'
import ListarProf from './professor/Listar'
import EditarProf from './professor/Editar'

const MP = () => {
    return (
        //As rotas são enxergadas por todos nesse contexto BrowserRouter -> contexto
        <BrowserRouter>
            <MenuV1 />
            <Routes>
                <Route path="cadProfessor" element={<CadastrarProf />} />
                <Route path="listProfessor" element={<ListarProf />} />
                <Route path="editProfessor" element={<EditarProf />} />
            </Routes>
        </BrowserRouter>
    )
}

export default MP